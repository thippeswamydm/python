
num = 10
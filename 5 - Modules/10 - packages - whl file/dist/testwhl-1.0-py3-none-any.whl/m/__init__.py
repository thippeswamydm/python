
__all__ = ["strvars", "numvars", "printme"]
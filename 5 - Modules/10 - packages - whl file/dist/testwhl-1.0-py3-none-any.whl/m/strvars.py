
name = "test"
num = 10